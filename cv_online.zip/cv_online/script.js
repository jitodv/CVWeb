// ========================
// Sistema de idiomas
// ========================
let currentLanguage = localStorage.getItem('language') || 'es';

// Función para cambiar idioma
function changeLanguage(lang) {
    currentLanguage = lang;
    localStorage.setItem('language', lang);
    
    // Actualizar botón de idioma
    const langBtn = document.querySelector('.lang-btn');
    const langFlags = {
        es: 'https://flagcdn.com/w20/es.png',
        ca: 'https://shorturl.at/czZnr',
        en: './images/usuk.png',
        de: 'https://flagcdn.com/w20/de.png'
    };
    const langNames = {
        es: 'ES',
        ca: 'CA',
        en: 'EN',
        de: 'DE'
    };
    langBtn.innerHTML = `<img src="${langFlags[lang]}" alt="${langNames[lang]}" class="flag-icon"> ${langNames[lang]} <i class="fas fa-chevron-down"></i>`;
    
    // Traducir todos los elementos con data-i18n
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const keys = element.getAttribute('data-i18n').split('.');
        let translation = translations[lang];
        
        for (let key of keys) {
            translation = translation[key];
        }
        
        if (translation) {
            element.innerHTML = translation;
        }
    });
    
    // Cerrar dropdown
    document.querySelector('.lang-dropdown').classList.remove('active');
}

// Inicializar idioma al cargar
document.addEventListener('DOMContentLoaded', () => {
    changeLanguage(currentLanguage);
    
    // Event listeners para opciones de idioma
    document.querySelectorAll('.lang-option').forEach(option => {
        option.addEventListener('click', (e) => {
            e.preventDefault();
            const lang = option.getAttribute('data-lang');
            changeLanguage(lang);
        });
    });
    
    // Toggle dropdown de idiomas
    const langBtn = document.querySelector('.lang-btn');
    const langDropdown = document.querySelector('.lang-dropdown');
    
    langBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        langDropdown.classList.toggle('active');
    });
    
    // Cerrar dropdown al hacer click fuera
    document.addEventListener('click', () => {
        langDropdown.classList.remove('active');
    });
});

// ========================
// Variables globales
// ========================
let lastScrollTop = 0;
const navbar = document.getElementById('navbar');
const navLinks = document.querySelectorAll('.nav-link');
const sections = document.querySelectorAll('section[id]');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const themeToggle = document.getElementById('themeToggle');
const scrollTop = document.getElementById('scrollTop');

// ========================
// Navbar scroll effect
// ========================
window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Agregar clase scrolled al navbar
    if (scrollTop > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
    
    // Mostrar/ocultar botón scroll to top
    const scrollTopBtn = document.getElementById('scrollTop');
    if (scrollTop > 300) {
        scrollTopBtn.classList.add('visible');
    } else {
        scrollTopBtn.classList.remove('visible');
    }
    
    lastScrollTop = scrollTop;
});

// ========================
// Navegación activa según scroll
// ========================
window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ========================
// Smooth scroll para los enlaces
// ========================
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 70;
            
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
            
            // Cerrar menú móvil si está abierto
            navMenu.classList.remove('active');
            hamburger.classList.remove('active');
        }
    });
});

// ========================
// Menú hamburguesa (móvil)
// ========================
hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Cerrar menú al hacer click fuera
document.addEventListener('click', (e) => {
    if (!navMenu.contains(e.target) && !hamburger.contains(e.target)) {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    }
});

// ========================
// Tema claro/oscuro
// ========================
const savedTheme = localStorage.getItem('theme') || 'light';
if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    
    if (document.body.classList.contains('dark-theme')) {
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        localStorage.setItem('theme', 'dark');
    } else {
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        localStorage.setItem('theme', 'light');
    }
});

// ========================
// Scroll to top
// ========================
scrollTop.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// ========================
// Animación de entrada para elementos
// ========================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const fadeInObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

// Aplicar animación a diferentes elementos
const fadeElements = document.querySelectorAll(
    '.about-content, .skill-category, .timeline-item, .cert-card, .project-card, .contact-content'
);

fadeElements.forEach(element => {
    element.classList.add('fade-in');
    fadeInObserver.observe(element);
});

// ========================
// Animación de barras de habilidades
// ========================
const skillsSection = document.getElementById('habilidades');
let skillsAnimated = false;

const skillsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !skillsAnimated) {
            animateSkills();
            skillsAnimated = true;
        }
    });
}, { threshold: 0.3 });

if (skillsSection) {
    skillsObserver.observe(skillsSection);
}

function animateSkills() {
    const skillBars = document.querySelectorAll('.skill-progress');
    
    skillBars.forEach((bar, index) => {
        const progress = bar.getAttribute('data-progress');
        
        // Remover el !important temporalmente y forzar el reflow
        bar.style.transition = 'none';
        bar.style.width = '0%';
        
        // Forzar reflow
        void bar.offsetWidth;
        
        // Restaurar transición y animar
        bar.style.transition = 'width 1.5s ease-out';
        
        setTimeout(() => {
            bar.style.width = progress + '%';
            bar.classList.add('animated');
        }, 100 + (index * 30));
    });
    
    // Agregar clase visible a las categorías
    const skillCategories = document.querySelectorAll('.skill-category');
    skillCategories.forEach((category, index) => {
        setTimeout(() => {
            category.classList.add('visible');
        }, index * 100);
    });
}

// ========================
// Contador animado para estadísticas
// ========================
const statsSection = document.querySelector('.about-stats');
let statsAnimated = false;

const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !statsAnimated) {
            animateStats();
            statsAnimated = true;
        }
    });
}, { threshold: 0.5 });

if (statsSection) {
    statsObserver.observe(statsSection);
}

function animateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        const text = stat.textContent;
        const number = parseInt(text);
        
        if (!isNaN(number)) {
            let current = 0;
            const increment = number / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= number) {
                    stat.textContent = text;
                    clearInterval(timer);
                } else {
                    stat.textContent = Math.floor(current) + '+';
                }
            }, 30);
        }
    });
}

// ========================
// Formulario de contacto
// ========================
const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');

if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Obtener datos del formulario
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value
        };
        
        // Validación básica
        if (!formData.name || !formData.email || !formData.subject || !formData.message) {
            showMessage('Por favor, completa todos los campos.', 'error');
            return;
        }
        
        // Validar email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            showMessage('Por favor, introduce un email válido.', 'error');
            return;
        }
        
        // Simulación de envío (aquí deberías implementar el envío real)
        try {
            // Simular delay de envío
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Aquí implementarías el envío real del formulario
            // Por ejemplo, usando fetch a tu backend o servicio de email
            /*
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            if (response.ok) {
                showMessage('¡Mensaje enviado correctamente! Te responderé pronto.', 'success');
                contactForm.reset();
            } else {
                throw new Error('Error al enviar');
            }
            */
            
            // Por ahora, solo mostramos mensaje de éxito
            showMessage('¡Mensaje enviado correctamente! Te responderé pronto.', 'success');
            contactForm.reset();
            
            console.log('Datos del formulario:', formData);
            
        } catch (error) {
            showMessage('Hubo un error al enviar el mensaje. Por favor, intenta de nuevo.', 'error');
            console.error('Error:', error);
        }
    });
}

function showMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = `form-message ${type}`;
    formMessage.style.display = 'block';
    
    // Ocultar mensaje después de 5 segundos
    setTimeout(() => {
        formMessage.style.display = 'none';
    }, 5000);
}

// ========================
// Partículas en el fondo del hero (opcional)
// ========================
function createParticles() {
    const heroBackground = document.querySelector('.hero-background');
    if (!heroBackground) return;
    
    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
            position: absolute;
            width: ${Math.random() * 5 + 2}px;
            height: ${Math.random() * 5 + 2}px;
            background: rgba(102, 126, 234, ${Math.random() * 0.5 + 0.2});
            border-radius: 50%;
            top: ${Math.random() * 100}%;
            left: ${Math.random() * 100}%;
            animation: float ${Math.random() * 10 + 10}s infinite ease-in-out;
            animation-delay: ${Math.random() * 5}s;
        `;
        heroBackground.appendChild(particle);
    }
}

// Descomentar si quieres partículas animadas
// createParticles();

// ========================
// Efecto de escritura para el título (opcional)
// ========================
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.textContent = '';
    
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Descomentar si quieres efecto de escritura
// const heroTitle = document.querySelector('.hero-title');
// if (heroTitle) {
//     const originalText = heroTitle.textContent;
//     typeWriter(heroTitle, originalText, 50);
// }

// ========================
// Prevenir comportamiento por defecto en enlaces de proyectos
// ========================
const projectLinks = document.querySelectorAll('.project-link');
projectLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        alert('Aquí iría el enlace al proyecto. Personaliza estos enlaces con tus proyectos reales.');
    });
});

// ========================
// Lazy loading para imágenes
// ========================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
                imageObserver.unobserve(img);
            }
        });
    });
    
    const lazyImages = document.querySelectorAll('img[data-src]');
    lazyImages.forEach(img => imageObserver.observe(img));
}

// ========================
// Efecto parallax suave
// ========================
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const heroBackground = document.querySelector('.hero-background');
    
    if (heroBackground && scrolled < window.innerHeight) {
        heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// ========================
// Animación de entrada para las cards de proyectos
// ========================
const projectCards = document.querySelectorAll('.project-card');
projectCards.forEach((card, index) => {
    card.style.animationDelay = `${index * 0.1}s`;
});

// ========================
// Copiar email al hacer click
// ========================
const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
emailLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        const email = link.getAttribute('href').replace('mailto:', '');
        
        // Copiar al portapapeles
        if (navigator.clipboard) {
            navigator.clipboard.writeText(email).then(() => {
                // Crear notificación temporal
                const notification = document.createElement('div');
                notification.textContent = '¡Email copiado al portapapeles!';
                notification.style.cssText = `
                    position: fixed;
                    bottom: 30px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: linear-gradient(135deg, #667eea, #764ba2);
                    color: white;
                    padding: 15px 30px;
                    border-radius: 50px;
                    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                    z-index: 10000;
                    animation: slideUp 0.3s ease-out;
                `;
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.style.animation = 'slideDown 0.3s ease-out';
                    setTimeout(() => notification.remove(), 300);
                }, 2000);
            });
        }
    });
});

// ========================
// Añadir estilos para animaciones de notificación
// ========================
const style = document.createElement('style');
style.textContent = `
    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateX(-50%) translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
    }
    
    @keyframes slideDown {
        from {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        to {
            opacity: 0;
            transform: translateX(-50%) translateY(20px);
        }
    }
`;
document.head.appendChild(style);

// ========================
// Inicialización al cargar la página
// ========================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio cargado correctamente');
    
    // Agregar clase de carga inicial
    document.body.classList.add('loaded');
    
    // Animar elementos iniciales
    setTimeout(() => {
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            heroContent.style.opacity = '1';
        }
    }, 100);
});

// ========================
// Manejo de errores global
// ========================
window.addEventListener('error', (e) => {
    console.error('Error:', e.error);
});

// ========================
// Performance: reducir animaciones si el usuario prefiere
// ========================
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.style.scrollBehavior = 'auto';
}

console.log('🚀 Portfolio inicializado correctamente');
console.log('💡 Personaliza tu información en el HTML');
console.log('🎨 Ajusta los colores en el CSS (variables CSS)');
console.log('📧 Configura el envío de emails en el formulario de contacto');
