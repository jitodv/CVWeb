# 🎓 Guía de Imágenes para Formación Académica

## 📸 Imágenes Necesarias

Para que tu sección de **Formación Académica** se vea completa, necesitas añadir los logos de los centros educativos en la carpeta `images/`.

### Archivos requeridos:

```
cv_online/
└── images/
    ├── escuela-llibertat.png    ← Logo de Escola Llibertat
    ├── instituto.png            ← Logo de tu instituto (ESO)
    └── fp-sistemas.png          ← Logo de tu centro de FP
```

## 📐 Especificaciones de las Imágenes

- **Tamaño**: 120x120px (cuadrada)
- **Formato**: PNG (preferible) o JPG
- **Peso**: Máximo 100KB cada una
- **Fondo**: Puede ser transparente (PNG) o de color

## 🎨 Dónde Conseguir los Logos

### 1. **Sitio Web Oficial del Centro**
- Busca el logo en la web oficial de tu escuela/instituto
- Generalmente está en el header o footer
- Haz clic derecho > "Guardar imagen como..."

### 2. **Google Images**
Busca: `"nombre del centro" logo png`

### 3. **Contactar al Centro**
- Escríbeles un email pidiendo su logo oficial
- Suelen tener versión digital de alta calidad

### 4. **Si No Encuentras el Logo**
¡No te preocupes! El código ya incluye **placeholders** (imágenes de respaldo) que se mostrarán automáticamente si no subes las imágenes.

## 🖼️ Cómo Optimizar las Imágenes

### Opción 1: Online (Gratis)
1. Ve a **TinyPNG.com** o **Squoosh.app**
2. Sube el logo
3. Descarga la versión optimizada
4. Renómbrala según corresponda

### Opción 2: Con Software
```bash
# Si tienes ImageMagick instalado
magick convert logo.png -resize 120x120 -quality 85 escuela-llibertat.png
```

## 📝 Personalizar la Formación

### Editar títulos, fechas y descripciones

Abre `index.html` y busca la sección **Formación Académica** (aprox. línea 378).

Cada tarjeta tiene esta estructura:

```html
<div class="education-card">
    <div class="education-logo">
        <img src="./images/NOMBRE-ARCHIVO.png" alt="Nombre Centro">
    </div>
    <div class="education-content">
        <div class="education-header">
            <h3>TÍTULO DE LA FORMACIÓN</h3>
            <span class="education-year">AÑO INICIO - AÑO FIN</span>
        </div>
        <h4>NOMBRE DEL CENTRO</h4>
        <p class="education-description">
            DESCRIPCIÓN DE LO QUE APRENDISTE O HICISTE
        </p>
    </div>
</div>
```

### Ejemplo Real:

```html
<div class="education-card">
    <div class="education-logo">
        <img src="./images/escuela-llibertat.png" alt="Escola Llibertat">
    </div>
    <div class="education-content">
        <div class="education-header">
            <h3>Educación Primaria</h3>
            <span class="education-year">2010 - 2016</span>
        </div>
        <h4>Escola Llibertat</h4>
        <p class="education-description">
            Formación primaria con énfasis en ciencias y tecnología.
        </p>
    </div>
</div>
```

## ➕ Añadir Más Centros Educativos

Para añadir un nuevo centro educativo, copia y pega este bloque en `index.html` dentro de `<div class="education-container">`:

```html
<!-- Nueva Formación -->
<div class="education-card">
    <div class="education-logo">
        <img src="./images/nombre-centro.png" alt="Nombre Centro" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjEyMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTIwIiBoZWlnaHQ9IjEyMCIgZmlsbD0iIzY2N2VlYSIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LXNpemU9IjQwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkVEVTwvdGV4dD48L3N2Zz4='">
    </div>
    <div class="education-content">
        <div class="education-header">
            <h3>Título de la Formación</h3>
            <span class="education-year">2022 - 2024</span>
        </div>
        <h4>Nombre del Centro Educativo</h4>
        <p class="education-description">
            Breve descripción de lo que aprendiste o lograste en esta formación.
        </p>
    </div>
</div>
```

## 🎨 Ejemplos de Descripciones

### Para Primaria:
> "Formación primaria completa con especial énfasis en ciencias y matemáticas. Participación en proyectos de tecnología y primeros contactos con la informática."

### Para ESO:
> "Completada la educación secundaria con enfoque en ciencias y tecnología. Desarrollo de habilidades técnicas y primeros proyectos de programación."

### Para Bachillerato:
> "Bachillerato de Ciencias Tecnológicas. Profundización en matemáticas, física y tecnología. Proyecto final sobre redes informáticas."

### Para FP/Ciclo Formativo:
> "Formación profesional especializada en administración de sistemas y redes. Conocimientos en virtualización, seguridad, servidores Linux/Windows, y gestión de infraestructuras IT."

### Para Universidad:
> "Grado en Ingeniería Informática con especialización en Sistemas y Redes. Proyecto final sobre automatización de despliegues con Kubernetes."

## ✅ Checklist

- [ ] Descargado logos de los centros educativos
- [ ] Optimizadas las imágenes (120x120px, <100KB)
- [ ] Guardadas en carpeta `images/` con nombres correctos
- [ ] Actualizados títulos de formación
- [ ] Actualizadas fechas (años)
- [ ] Personalizadas descripciones
- [ ] Verificado que se ven bien en el navegador
- [ ] Probado en móvil (responsive)

## 💡 Tips

1. **Orden cronológico**: Pon primero la formación más reciente
2. **Sé específico**: Menciona especialidades o proyectos destacados
3. **Breve pero informativo**: 2-3 líneas por descripción
4. **Coherencia**: Usa el mismo estilo de redacción en todas

---

**Nota**: Si no tienes los logos ahora, ¡no hay problema! Los placeholders SVG se ven profesionales y puedes añadir los logos reales más tarde.
