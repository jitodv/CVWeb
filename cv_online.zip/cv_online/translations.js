// ========================
// Sistema de traducciones multiidioma
// ========================

const translations = {
    es: {
        // Navegación
        nav: {
            home: "Inicio",
            about: "Sobre Mí",
            skills: "Habilidades",
            experience: "Experiencia",
            education: "Formación",
            projects: "Proyectos",
            contact: "Contacto"
        },
        // Hero
        hero: {
            greeting: "Hola, soy",
            name: "Rubén Guerrero",
            title: "Administrador de Sistemas",
            description: "Especializado en infraestructuras IT, virtualización, seguridad y automatización de sistemas",
            contactBtn: "Contáctame",
            projectsBtn: "Ver Proyectos"
        },
        // Sobre mí
        about: {
            title: "Sobre Mí",
            text1: "Soy un administrador de sistemas apasionado por la tecnología con <strong>1 año de experiencia</strong> trabajando con infraestructuras IT. A lo que más me he dedicado es en crear soluciones en sistemas seguras y escalables.",
            text2: "He trabajado con diversas tecnologías y plataformas, incluyendo Linux, Windows Server, virtualización y servicios en la nube, también tengo experiencia en scripting para automatizar tareas administrativas y también en la gestión de redes y seguridad informática.",
            stat1Label: "Año de Experiencia",
            stat2Label: "Proyectos Completados",
            stat3Label: "Certificaciones",
            downloadCV: "Descargar CV"
        },
        // Habilidades
        skills: {
            title: "Habilidades Técnicas",
            os: "Sistemas Operativos",
            virtualization: "Virtualización & Contenedores",
            networking: "Redes & Seguridad",
            automation: "Automatización & Scripting",
            cloud: "Cloud & DevOps",
            databases: "Bases de Datos"
        },
        // Experiencia
        experience: {
            title: "Experiencia Laboral",
            present: "Presente",
            job1: {
                title: "Administrador de Sistemas Junior",
                company: "Arrels-Esperança Escola S.L.U",
                task1: "Administración de sistemas Windows",
                task2: "Monitoreo y mantenimiento de sistemas",
                task3: "Implementación de políticas de seguridad y backups",
                task4: "Soporte técnico a usuarios y departamentos",
                task5: "Desarrollo de Scripts de automatización"
            },
            job2: {
                title: "Técnico en Sistemas Microinformáticos y Redes",
                company: "A.A.V.V Bufalà",
                task1: "Soporte técnico y mantenimiento de equipos",
                task2: "Instalación y configuración de equipos",
                task3: "Gestión de redes y Bases de datos"
            }
        },
        // Formación
        education: {
            title: "Formación Académica",
            cert1: {
                title: "Google: IA Práctica para Marketing",
                institution: "Santander Open Academy",
                year: "2025",
                description: "Al realizar este curso, he aprendido a dominar la IA de Google (Gemini, GA4) para analizar audiencias y generar contenido atractivo. Aprendí a optimizar campañas con Performance Max y a transformar datos en decisiones estratégicas. Mi principal aprendizaje adquirido es redactar prompts efectivos con el marco TCREI, esencial para mi trabajo diario."
            },
            cert2: {
                title: "CFGS Administración de Sistemas Informáticos en Red",
                institution: "Institut La Pineda",
                year: "2023 - 2025",
                description: "Al completar el CFGS de ASIR, he aprendido a administrar y mantener sistemas operativos robustos (Windows y Linux) y a gestionar integralmente la infraestructura de red de una empresa. Mi principal aprendizaje adquirido es la implementación y configuración de servicios de red clave (DNS, DHCP, Web, correo) y el manejo de entornos de virtualización y cloud. Todo ello con un enfoque sólido en la seguridad informática y la automatización mediante scripting, esencial para la continuidad del negocio."
            },
            cert3: {
                title: "CFGM Sistemas Microinformáticos y redes",
                institution: "Institut La Pineda",
                year: "2020 - 2023",
                description: "He desarrollado una base esencial en hardware y software para el soporte microinformático. En este ciclo formativo, mi principal aprendizaje adquirido es el montaje, configuración y reparación de equipos, además de la instalación y mantenimiento de sistemas operativos y aplicaciones. Soy competente en la gestión de redes de área local (cableadas e inalámbricas) y en la asistencia técnica a usuarios, resolviendo eficazmente cualquier incidencia diaria."
            },
            cert4: {
                title: "Educación Secundaria Obligatoria (ESO)",
                institution: "Institut La Pineda",
                year: "2016 - 2020",
                description: "Completada la educación secundaria con enfoque en ciencias y tecnología. Desarrollo de habilidades técnicas y primeros proyectos de programación en Python."
            },
            cert5: {
                title: "Educación Primaria",
                institution: "Escola Llibertat",
                year: "2010 - 2016",
                description: "Formación primaria completa con especial énfasis en ciencias y matemáticas. Participación en proyectos de tecnología y primeros contactos con la informática."
            }
        },
        // Proyectos
        projects: {
            title: "Proyectos Destacados",
            project1: {
                title: "Discoteca Fantasy",
                description: "Proyecto en el que realizamos la infraestructura IT de una discoteca utilizando los conocimientos adquiridos durante el transcurso de nuestra formación como técnicos en sistemas. TFG"
            },
            project2: {
                title: "IVPack | FiveM",
                description: "Adaptación del mod del famoso videojuego Grand Theft Auto V para la plataforma multijugador FiveM."
            },
            project3: {
                title: "Multiherramienta Fennec",
                description: "Programa de scripting en PowerShell para la automatización de diferentes tareas en entornos Windows."
            },
            project4: {
                title: "Zona Medusa | FiveM",
                description: "Script para FiveM de mi amigo ",
                descriptionLink: "@Ziccur",
                descriptionEnd: " donde colaboré en el proceso de desarrollo, optimización y testeo."
            }
        },
        // Contacto
        contact: {
            title: "Contacto",
            heading: "¿Hablamos?",
            intro: "Estoy abierto a nuevas oportunidades y colaboraciones. Si tienes alguna pregunta o quieres discutir un proyecto, no dudes en contactarme.",
            email: "Email",
            phone: "Teléfono",
            location: "Ubicación",
            locationValue: "Barcelona, España",
            formName: "Nombre",
            formEmail: "Email",
            formSubject: "Asunto",
            formMessage: "Mensaje",
            formSubmit: "Enviar Mensaje"
        },
        // Footer
        footer: {
            rights: "Todos los derechos reservados."
        }
    },

    ca: {
        // Navegació
        nav: {
            home: "Inici",
            about: "Sobre Mi",
            skills: "Habilitats",
            experience: "Experiència",
            education: "Formació",
            projects: "Projectes",
            contact: "Contacte"
        },
        // Hero
        hero: {
            greeting: "Hola, sóc",
            name: "Rubén Guerrero",
            title: "Administrador de Sistemes",
            description: "Especialitzat en infraestructures IT, virtualització, seguretat i automatització de sistemes",
            contactBtn: "Contacta'm",
            projectsBtn: "Veure Projectes"
        },
        // Sobre mi
        about: {
            title: "Sobre Mi",
            text1: "Sóc un administrador de sistemes apassionat per la tecnologia amb <strong>1 any d'experiència</strong> treballant amb infraestructures IT. A què més m'he dedicat és a crear solucions en sistemes segures i escalables.",
            text2: "He treballat amb diverses tecnologies i plataformes, incloent Linux, Windows Server, virtualització i serveis al núvol, també tinc experiència en scripting per automatitzar tasques administratives i també en la gestió de xarxes i seguretat informàtica.",
            stat1Label: "Any d'Experiència",
            stat2Label: "Projectes Completats",
            stat3Label: "Certificacions",
            downloadCV: "Descarregar CV"
        },
        // Habilitats
        skills: {
            title: "Habilitats Tècniques",
            os: "Sistemes Operatius",
            virtualization: "Virtualització i Contenidors",
            networking: "Xarxes i Seguretat",
            automation: "Automatització i Scripting",
            cloud: "Cloud i DevOps",
            databases: "Bases de Dades"
        },
        // Experiència
        experience: {
            title: "Experiència Laboral",
            present: "Present",
            job1: {
                title: "Administrador de Sistemes Junior",
                company: "Arrels-Esperança Escola S.L.U",
                task1: "Administració de sistemes Windows",
                task2: "Monitoratge i manteniment de sistemes",
                task3: "Implementació de polítiques de seguretat i còpies de seguretat",
                task4: "Suport tècnic a usuaris i departaments",
                task5: "Desenvolupament de Scripts d'automatització"
            },
            job2: {
                title: "Tècnic en Sistemes Microinformàtics i Xarxes",
                company: "A.A.V.V Bufalà",
                task1: "Suport tècnic i manteniment d'equips",
                task2: "Instal·lació i configuració d'equips",
                task3: "Gestió de xarxes i bases de dades"
            }
        },
        // Formació
        education: {
            title: "Formació Acadèmica",
            cert1: {
                title: "Google: IA Pràctica per a Màrqueting",
                institution: "Santander Open Academy",
                year: "2025",
                description: "En realitzar aquest curs, he après a dominar la IA de Google (Gemini, GA4) per analitzar audiències i generar contingut atractiu. Vaig aprendre a optimitzar campanyes amb Performance Max i a transformar dades en decisions estratègiques. El meu principal aprenentatge adquirit és redactar prompts efectius amb el marc TCREI, essencial per al meu treball diari."
            },
            cert2: {
                title: "CFGS Administració de Sistemes Informàtics en Xarxa",
                institution: "Institut La Pineda",
                year: "2023 - 2025",
                description: "En completar el CFGS d'ASIX, he après a administrar i mantenir sistemes operatius robustos (Windows i Linux) i a gestionar integralment la infraestructura de xarxa d'una empresa. El meu principal aprenentatge adquirit és la implementació i configuració de serveis de xarxa clau (DNS, DHCP, Web, correu) i el maneig d'entorns de virtualització i cloud. Tot això amb un enfocament sòlid en la seguretat informàtica i l'automatització mitjançant scripting, essencial per a la continuïtat del negoci."
            },
            cert3: {
                title: "CFGM Sistemes Microinformàtics i Xarxes",
                institution: "Institut La Pineda",
                year: "2020 - 2023",
                description: "He desenvolupat una base essencial en maquinari i programari per al suport microinformàtic. En aquest cicle formatiu, el meu principal aprenentatge adquirit és el muntatge, configuració i reparació d'equips, a més de la instal·lació i manteniment de sistemes operatius i aplicacions. Sóc competent en la gestió de xarxes d'àrea local (cablejades i sense fils) i en l'assistència tècnica a usuaris, resolent eficaçment qualsevol incidència diària."
            },
            cert4: {
                title: "Educació Secundària Obligatòria (ESO)",
                institution: "Institut La Pineda",
                year: "2016 - 2020",
                description: "Completada l'educació secundària amb enfocament en ciències i tecnologia. Desenvolupament d'habilitats tècniques i primers projectes de programació en Python."
            },
            cert5: {
                title: "Educació Primària",
                institution: "Escola Llibertat",
                year: "2010 - 2016",
                description: "Formació primària completa amb especial èmfasi en ciències i matemàtiques. Participació en projectes de tecnologia i primers contactes amb la informàtica."
            }
        },
        // Projectes
        projects: {
            title: "Projectes Destacats",
            project1: {
                title: "Discoteca Fantasy",
                description: "Projecte en el qual vam realitzar la infraestructura IT d'una discoteca utilitzant els coneixements adquirits durant el transcurs de la nostra formació com a tècnics en sistemes. TFG"
            },
            project2: {
                title: "IVPack | FiveM",
                description: "Adaptació del mod del famós videojoc Grand Theft Auto V per a la plataforma multijugador FiveM."
            },
            project3: {
                title: "Multiherramienta Fennec",
                description: "Programa de scripting en PowerShell per a l'automatització de diferents tasques en entorns Windows."
            },
            project4: {
                title: "Zona Medusa | FiveM",
                description: "Script per a FiveM del meu amic ",
                descriptionLink: "@Ziccur",
                descriptionEnd: " on vaig col·laborar en el procés de desenvolupament, optimització i testeig."
            }
        },
        // Contacte
        contact: {
            title: "Contacte",
            heading: "Parlem?",
            intro: "Estic obert a noves oportunitats i col·laboracions. Si tens alguna pregunta o vols discutir un projecte, no dubtis a contactar-me.",
            email: "Correu electrònic",
            phone: "Telèfon",
            location: "Ubicació",
            locationValue: "Barcelona, Espanya",
            formName: "Nom",
            formEmail: "Correu electrònic",
            formSubject: "Assumpte",
            formMessage: "Missatge",
            formSubmit: "Enviar Missatge"
        },
        // Footer
        footer: {
            rights: "Tots els drets reservats."
        }
    },

    en: {
        // Navigation
        nav: {
            home: "Home",
            about: "About Me",
            skills: "Skills",
            experience: "Experience",
            education: "Education",
            projects: "Projects",
            contact: "Contact"
        },
        // Hero
        hero: {
            greeting: "Hi, I'm",
            name: "Rubén Guerrero",
            title: "Systems Administrator",
            description: "Specialized in IT infrastructure, virtualization, security and systems automation",
            contactBtn: "Contact Me",
            projectsBtn: "View Projects"
        },
        // About
        about: {
            title: "About Me",
            text1: "I am a systems administrator passionate about technology with <strong>1 year of experience</strong> working with IT infrastructures. What I have mostly focused on is creating secure and scalable system solutions.",
            text2: "I have worked with various technologies and platforms, including Linux, Windows Server, virtualization and cloud services, I also have experience in scripting to automate administrative tasks and also in network management and cybersecurity.",
            stat1Label: "Year of Experience",
            stat2Label: "Completed Projects",
            stat3Label: "Certifications",
            downloadCV: "Download CV"
        },
        // Skills
        skills: {
            title: "Technical Skills",
            os: "Operating Systems",
            virtualization: "Virtualization & Containers",
            networking: "Networking & Security",
            automation: "Automation & Scripting",
            cloud: "Cloud & DevOps",
            databases: "Databases"
        },
        // Experience
        experience: {
            title: "Work Experience",
            present: "Present",
            job1: {
                title: "Junior Systems Administrator",
                company: "Arrels-Esperança Escola S.L.U",
                task1: "Windows systems administration",
                task2: "System monitoring and maintenance",
                task3: "Implementation of security policies and backups",
                task4: "Technical support to users and departments",
                task5: "Development of automation scripts"
            },
            job2: {
                title: "Microcomputer Systems and Networks Technician",
                company: "A.A.V.V Bufalà",
                task1: "Technical support and equipment maintenance",
                task2: "Equipment installation and configuration",
                task3: "Network and database management"
            }
        },
        // Education
        education: {
            title: "Academic Education",
            cert1: {
                title: "Google: Practical AI for Marketing",
                institution: "Santander Open Academy",
                year: "2025",
                description: "By completing this course, I learned to master Google's AI (Gemini, GA4) to analyze audiences and generate engaging content. I learned to optimize campaigns with Performance Max and transform data into strategic decisions. My main learning acquired is writing effective prompts with the TCREI framework, essential for my daily work."
            },
            cert2: {
                title: "CFGS Administración de Sistemas Informáticos en Red | Higher Degree in Network Systems Administration",
                institution: "Institut La Pineda",
                year: "2023 - 2025",
                description: "Upon completing the ASIR Higher Degree, I learned to administer and maintain robust operating systems (Windows and Linux) and comprehensively manage a company's network infrastructure. My main learning acquired is the implementation and configuration of key network services (DNS, DHCP, Web, mail) and the management of virtualization and cloud environments. All with a solid focus on computer security and automation through scripting, essential for business continuity."
            },
            cert3: {
                title: "CFGM Sistemas Microinformáticos y Redes | Intermediate Degree in Microcomputer Systems and Networks",
                institution: "Institut La Pineda",
                year: "2020 - 2023",
                description: "I have developed an essential foundation in hardware and software for microcomputer support. In this training cycle, my main learning acquired is the assembly, configuration and repair of equipment, as well as the installation and maintenance of operating systems and applications. I am competent in managing local area networks (wired and wireless) and in providing technical assistance to users, effectively resolving any daily incidents."
            },
            cert4: {
                title: "Educación Secundaria Obligatoria (ESO) | Compulsory Secondary Education",
                institution: "Institut La Pineda",
                year: "2016 - 2020",
                description: "Completed secondary education with a focus on science and technology. Development of technical skills and first programming projects in Python."
            },
            cert5: {
                title: "Educación Primaria | Primary Education",
                institution: "Escola Llibertat",
                year: "2010 - 2016",
                description: "Complete primary education with special emphasis on science and mathematics. Participation in technology projects and first contacts with computer science."
            }
        },
        // Projects
        projects: {
            title: "Featured Projects",
            project1: {
                title: "Fantasy Nightclub",
                description: "Project in which we built the IT infrastructure for a nightclub using the knowledge acquired during our training as systems technicians. Final Project"
            },
            project2: {
                title: "IVPack | FiveM",
                description: "Adaptation of the mod from the famous Grand Theft Auto V video game for the FiveM multiplayer platform."
            },
            project3: {
                title: "Fennec Multi-tool",
                description: "PowerShell scripting program for automating different tasks in Windows environments."
            },
            project4: {
                title: "Zona Medusa | FiveM",
                description: "Script for FiveM by my friend ",
                descriptionLink: "@Ziccur",
                descriptionEnd: " where I collaborated in the development, optimization and testing process."
            }
        },
        // Contact
        contact: {
            title: "Contact",
            heading: "Let's Talk?",
            intro: "I am open to new opportunities and collaborations. If you have any questions or want to discuss a project, feel free to contact me.",
            email: "Email",
            phone: "Phone",
            location: "Location",
            locationValue: "Barcelona, Spain",
            formName: "Name",
            formEmail: "Email",
            formSubject: "Subject",
            formMessage: "Message",
            formSubmit: "Send Message"
        },
        // Footer
        footer: {
            rights: "All rights reserved."
        }
    },

    de: {
        // Navigation
        nav: {
            home: "Startseite",
            about: "Über mich",
            skills: "Fähigkeiten",
            experience: "Erfahrung",
            education: "Ausbildung",
            projects: "Projekte",
            contact: "Kontakt"
        },
        // Hero
        hero: {
            greeting: "Hallo, ich bin",
            name: "Rubén Guerrero",
            title: "Systemadministrator",
            description: "Spezialisiert auf IT-Infrastruktur, Virtualisierung, Sicherheit und Systemautomatisierung",
            contactBtn: "Kontaktieren Sie mich",
            projectsBtn: "Projekte ansehen"
        },
        // About
        about: {
            title: "Über Mich",
            text1: "Ich bin ein leidenschaftlicher Systemadministrator für Technologie mit <strong>1 Jahr Erfahrung</strong> in der Arbeit mit IT-Infrastrukturen. Worauf ich mich am meisten konzentriert habe, ist die Erstellung sicherer und skalierbarer Systemlösungen.",
            text2: "Ich habe mit verschiedenen Technologien und Plattformen gearbeitet, darunter Linux, Windows Server, Virtualisierung und Cloud-Dienste, ich habe auch Erfahrung in Skripting zur Automatisierung administrativer Aufgaben und auch in Netzwerkverwaltung und IT-Sicherheit.",
            stat1Label: "Jahr Erfahrung",
            stat2Label: "Abgeschlossene Projekte",
            stat3Label: "Zertifizierungen",
            downloadCV: "Lebenslauf herunterladen"
        },
        // Skills
        skills: {
            title: "Technische Fähigkeiten",
            os: "Betriebssysteme",
            virtualization: "Virtualisierung & Container",
            networking: "Netzwerke & Sicherheit",
            automation: "Automatisierung & Scripting",
            cloud: "Cloud & DevOps",
            databases: "Datenbanken"
        },
        // Experience
        experience: {
            title: "Berufserfahrung",
            present: "Gegenwart",
            job1: {
                title: "Junior-Systemadministrator",
                company: "Arrels-Esperança Escola S.L.U",
                task1: "Windows-Systemadministration",
                task2: "Systemüberwachung und -wartung",
                task3: "Implementierung von Sicherheitsrichtlinien und Backups",
                task4: "Technischer Support für Benutzer und Abteilungen",
                task5: "Entwicklung von Automatisierungsskripten"
            },
            job2: {
                title: "Techniker für Mikrocomputersysteme und Netzwerke",
                company: "A.A.V.V Bufalà",
                task1: "Technischer Support und Gerätewartung",
                task2: "Geräteinstallation und -konfiguration",
                task3: "Netzwerk- und Datenbankverwaltung"
            }
        },
        // Education
        education: {
            title: "Akademische Ausbildung",
            cert1: {
                title: "Google: Praktische KI für Marketing",
                institution: "Santander Open Academy",
                year: "2025",
                description: "Durch den Abschluss dieses Kurses habe ich gelernt, die KI von Google (Gemini, GA4) zu beherrschen, um Zielgruppen zu analysieren und ansprechende Inhalte zu generieren. Ich habe gelernt, Kampagnen mit Performance Max zu optimieren und Daten in strategische Entscheidungen umzuwandeln. Mein wichtigstes erworbenes Wissen ist das Schreiben effektiver Prompts mit dem TCREI-Framework, das für meine tägliche Arbeit unerlässlich ist."
            },
            cert2: {
                title: "CFGS Administración de Sistemas Informáticos en Red | Höherer Abschluss in Netzwerksystemadministration",
                institution: "Institut La Pineda",
                year: "2023 - 2025",
                description: "Nach Abschluss des ASIR-Hochschulabschlusses habe ich gelernt, robuste Betriebssysteme (Windows und Linux) zu verwalten und die Netzwerkinfrastruktur eines Unternehmens umfassend zu verwalten. Mein wichtigstes erworbenes Wissen ist die Implementierung und Konfiguration wichtiger Netzwerkdienste (DNS, DHCP, Web, Mail) und die Verwaltung von Virtualisierungs- und Cloud-Umgebungen. Alles mit einem soliden Fokus auf Computersicherheit und Automatisierung durch Scripting, wesentlich für die Geschäftskontinuität."
            },
            cert3: {
                title: "CFGM Sistemas Microinformáticos y Redes | Mittlerer Abschluss in Mikrocomputersystemen und Netzwerken",
                institution: "Institut La Pineda",
                year: "2020 - 2023",
                description: "Ich habe eine wesentliche Grundlage in Hardware und Software für die Mikrocomputerunterstützung entwickelt. In diesem Ausbildungszyklus ist mein wichtigstes erworbenes Wissen die Montage, Konfiguration und Reparatur von Geräten sowie die Installation und Wartung von Betriebssystemen und Anwendungen. Ich bin kompetent in der Verwaltung lokaler Netzwerke (kabelgebunden und drahtlos) und in der technischen Unterstützung von Benutzern, wobei ich alle täglichen Vorfälle effektiv löse."
            },
            cert4: {
                title: "Educación Secundaria Obligatoria (ESO) | Pflichtschulbildung",
                institution: "Institut La Pineda",
                year: "2016 - 2020",
                description: "Abgeschlossene Sekundarschulbildung mit Schwerpunkt auf Naturwissenschaften und Technologie. Entwicklung technischer Fähigkeiten und erste Programmierprojekte in Python."
            },
            cert5: {
                title: "Educación Primaria | Grundschulbildung",
                institution: "Escola Llibertat",
                year: "2010 - 2016",
                description: "Vollständige Grundschulbildung mit besonderem Schwerpunkt auf Naturwissenschaften und Mathematik. Teilnahme an Technologieprojekten und erste Kontakte mit der Informatik."
            }
        },
        // Projects
        projects: {
            title: "Hervorgehobene Projekte",
            project1: {
                title: "Fantasy Nachtclub",
                description: "Projekt, in dem wir die IT-Infrastruktur für einen Nachtclub unter Verwendung der während unserer Ausbildung als Systemtechniker erworbenen Kenntnisse aufgebaut haben. Abschlussprojekt"
            },
            project2: {
                title: "IVPack | FiveM",
                description: "Anpassung des Mods aus dem berühmten Videospiel Grand Theft Auto V für die FiveM-Multiplayer-Plattform."
            },
            project3: {
                title: "Fennec Multi-Tool",
                description: "PowerShell-Scripting-Programm zur Automatisierung verschiedener Aufgaben in Windows-Umgebungen."
            },
            project4: {
                title: "Zona Medusa | FiveM",
                description: "Skript für FiveM von meinem Freund ",
                descriptionLink: "@Ziccur",
                descriptionEnd: ", bei dem ich am Entwicklungs-, Optimierungs- und Testprozess mitgewirkt habe."
            }
        },
        // Contact
        contact: {
            title: "Kontakt",
            heading: "Lass uns reden?",
            intro: "Ich bin offen für neue Möglichkeiten und Zusammenarbeit. Wenn Sie Fragen haben oder ein Projekt besprechen möchten, zögern Sie nicht, mich zu kontaktieren.",
            email: "E-Mail",
            phone: "Telefon",
            location: "Standort",
            locationValue: "Barcelona, Spanien",
            formName: "Name",
            formEmail: "E-Mail",
            formSubject: "Betreff",
            formMessage: "Nachricht",
            formSubmit: "Nachricht senden"
        },
        // Footer
        footer: {
            rights: "Alle Rechte vorbehalten."
        }
    }
};

// Exportar traducciones
if (typeof module !== 'undefined' && module.exports) {
    module.exports = translations;
}
