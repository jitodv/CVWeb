# 🚀 Portafolio Web Profesional - Administrador de Sistemas

Portafolio web moderno, responsive e interactivo desarrollado con **HTML5**, **CSS3** y **JavaScript** vanilla. Ideal para administradores de sistemas que buscan destacar en el mercado laboral.

## ✨ Características

### 🎨 Diseño
- ✅ Diseño moderno y profesional
- ✅ Totalmente responsive (móvil, tablet y escritorio)
- ✅ Tema claro/oscuro con persistencia en localStorage
- ✅ Animaciones suaves y efectos interactivos
- ✅ Gradientes y efectos visuales modernos

### 🛠️ Funcionalidades
- ✅ Navegación fluida con smooth scroll
- ✅ Menú hamburguesa para móviles
- ✅ Secciones dinámicas:
  - Hero section con información principal
  - Sobre mí con estadísticas animadas
  - Habilidades técnicas con barras de progreso animadas
  - Línea de tiempo de experiencia laboral
  - Certificaciones destacadas
  - Proyectos con imágenes y descripciones
  - Formulario de contacto funcional
- ✅ Botón "scroll to top"
- ✅ Animaciones al hacer scroll (Intersection Observer)
- ✅ Optimizado para SEO
- ✅ Accesibilidad mejorada

## 📁 Estructura del Proyecto

```
cv_online/
│
├── index.html          # Estructura principal del portafolio
├── styles.css          # Estilos y diseño responsive
├── script.js           # Interactividad y funcionalidades
├── README.md           # Este archivo
│
└── images/            # Carpeta para tus imágenes
    ├── profile.jpg    # Tu foto de perfil
    ├── project1.jpg   # Imagen del proyecto 1
    ├── project2.jpg   # Imagen del proyecto 2
    ├── project3.jpg   # Imagen del proyecto 3
    ├── project4.jpg   # Imagen del proyecto 4
    ├── project5.jpg   # Imagen del proyecto 5
    └── project6.jpg   # Imagen del proyecto 6
```

## 🎯 Personalización

### 1. Información Personal

Edita el archivo `index.html` y reemplaza los siguientes elementos:

**Información básica:**
- **Tu Nombre**: Busca `<span class="gradient-text">Tu Nombre</span>` (línea ~61)
- **Email**: Reemplaza `tu@email.com` en todos los lugares
- **Teléfono**: Cambia `+34 123 456 789`
- **Ubicación**: Actualiza `Madrid, España`
- **Redes sociales**: Actualiza los enlaces de LinkedIn, GitHub, Twitter

**Sobre ti:**
- Modifica el texto en la sección `#sobre-mi` (líneas ~100-140)
- Actualiza las estadísticas (años de experiencia, proyectos, certificaciones)

**Habilidades:**
- Ajusta los porcentajes de cada habilidad en `data-progress`
- Añade o elimina tecnologías según tu experiencia

**Experiencia laboral:**
- Actualiza las empresas, fechas y responsabilidades
- Modifica los tags de tecnologías

**Certificaciones:**
- Añade tus certificaciones reales con nombres y años

**Proyectos:**
- Describe tus proyectos destacados
- Añade enlaces reales a los proyectos
- Actualiza las tecnologías utilizadas

### 2. Colores y Diseño

Edita el archivo `styles.css` en las variables CSS (líneas 1-30):

```css
:root {
    --primary-color: #667eea;      /* Color principal */
    --primary-dark: #5568d3;       /* Color principal oscuro */
    --secondary-color: #764ba2;    /* Color secundario */
    --accent-color: #f093fb;       /* Color de acento */
}
```

### 3. Imágenes

**Foto de perfil:**
- Coloca tu foto en `images/profile.jpg`
- Tamaño recomendado: 400x400px (cuadrada)

**Imágenes de proyectos:**
- Añade capturas de tus proyectos en `images/`
- Tamaño recomendado: 800x600px
- Formato: JPG o PNG

**CV en PDF:**
- Coloca tu CV en la raíz del proyecto como `cv.pdf`

### 4. Formulario de Contacto

El formulario actualmente simula el envío. Para hacerlo funcional:

#### Opción 1: Usar FormSpree (Gratis)
```html
<form action="https://formspree.io/f/TU_FORM_ID" method="POST">
    <!-- campos del formulario -->
</form>
```

#### Opción 2: Usar EmailJS
1. Regístrate en [EmailJS](https://www.emailjs.com/)
2. Sigue su documentación para configurar el servicio
3. Actualiza el código en `script.js`

#### Opción 3: Backend propio
Implementa tu propio servidor backend con Node.js, PHP, etc.

## 🚀 Despliegue

### GitHub Pages (Gratis)

1. Crea un repositorio en GitHub
2. Sube todos los archivos
3. Ve a Settings > Pages
4. Selecciona la rama `main` como fuente
5. Tu sitio estará disponible en `https://tu-usuario.github.io/nombre-repo`

### Netlify (Gratis)

1. Regístrate en [Netlify](https://www.netlify.com/)
2. Arrastra la carpeta del proyecto a Netlify Drop
3. Tu sitio estará listo en segundos

### Vercel (Gratis)

1. Regístrate en [Vercel](https://vercel.com/)
2. Conecta tu repositorio de GitHub
3. Despliega automáticamente

### Hosting tradicional

Sube los archivos vía FTP a cualquier hosting web que soporte HTML/CSS/JS.

## 📱 Navegadores Compatibles

- ✅ Chrome (últimas 2 versiones)
- ✅ Firefox (últimas 2 versiones)
- ✅ Safari (últimas 2 versiones)
- ✅ Edge (últimas 2 versiones)
- ✅ Opera (últimas 2 versiones)

## 🔧 Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **CSS3**: Diseño moderno con Flexbox, Grid, Variables CSS
- **JavaScript (Vanilla)**: Interactividad sin frameworks
- **Font Awesome 6**: Iconos
- **Intersection Observer API**: Animaciones al scroll
- **Local Storage API**: Persistencia del tema

## 📊 Performance

- ⚡ Carga rápida (sin dependencias pesadas)
- 🎯 100% JavaScript vanilla (sin jQuery ni frameworks)
- 📦 Tamaño mínimo de archivos
- 🚀 Optimizado para SEO
- ♿ Accesible (ARIA labels, semántica)

## 💡 Consejos de Personalización

### Colores para Administradores de Sistemas
- **Azul tecnológico**: `#0066cc`, `#1e90ff`
- **Verde terminal**: `#00ff00`, `#33cc33`
- **Gris profesional**: `#2c3e50`, `#34495e`
- **Naranja energético**: `#ff6b35`, `#f7931e`

### Secciones Adicionales (Opcional)

Puedes añadir:
- **Blog**: Artículos técnicos
- **Testimonios**: Referencias de clientes o colegas
- **Timeline de formación**: Cursos y educación
- **Herramientas favoritas**: Software y tecnologías que usas

### SEO Básico

1. Actualiza el `<title>` en `index.html`
2. Modifica el `<meta name="description">` con tu descripción
3. Añade meta tags Open Graph para redes sociales:

```html
<meta property="og:title" content="Tu Nombre - Administrador de Sistemas">
<meta property="og:description" content="Portafolio profesional...">
<meta property="og:image" content="URL de tu imagen">
```

## 🐛 Solución de Problemas

**Las animaciones no funcionan:**
- Verifica que JavaScript esté habilitado
- Comprueba la consola del navegador (F12)

**El tema oscuro no persiste:**
- Verifica que Local Storage esté habilitado en tu navegador

**Las imágenes no cargan:**
- Verifica las rutas en `index.html`
- Asegúrate de que las imágenes estén en la carpeta `images/`

**El formulario no envía:**
- Implementa un servicio de backend (ver sección "Formulario de Contacto")

## 📄 Licencia

Este proyecto es de código abierto. Puedes usarlo libremente para tu portafolio personal.

## 🤝 Contribuciones

¡Siéntete libre de mejorar este portafolio! Si tienes sugerencias:

1. Haz un fork del proyecto
2. Crea una rama con tu mejora
3. Envía un pull request

## 📞 Soporte

Si tienes problemas o preguntas:
- Revisa la documentación
- Consulta la consola del navegador para errores
- Verifica que todos los archivos estén en las rutas correctas

## ✅ Checklist de Personalización

- [ ] Actualizar nombre y título
- [ ] Cambiar información personal (email, teléfono, ubicación)
- [ ] Actualizar enlaces de redes sociales
- [ ] Modificar sección "Sobre mí"
- [ ] Ajustar estadísticas
- [ ] Actualizar habilidades y porcentajes
- [ ] Completar experiencia laboral
- [ ] Añadir certificaciones reales
- [ ] Describir proyectos
- [ ] Subir imágenes (perfil y proyectos)
- [ ] Añadir CV en PDF
- [ ] Configurar formulario de contacto
- [ ] Personalizar colores (opcional)
- [ ] Probar en diferentes dispositivos
- [ ] Optimizar imágenes
- [ ] Desplegar en hosting

---

## 🎉 ¡Listo para Impresionar!

Tu portafolio está listo para mostrar al mundo tu experiencia como administrador de sistemas. 

**Recuerda:**
- Mantén la información actualizada
- Añade nuevos proyectos regularmente
- Optimiza las imágenes antes de subirlas
- Prueba en diferentes navegadores y dispositivos

**¡Mucha suerte en tu búsqueda laboral! 🚀**

---

*Desarrollado con ❤️ usando HTML, CSS y JavaScript*
