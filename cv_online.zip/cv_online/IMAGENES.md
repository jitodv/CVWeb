# 📸 Guía de Imágenes para tu Portafolio

## 🎯 Imágenes Necesarias

### 1. Foto de Perfil (profile.jpg)
- **Tamaño**: 400x400px (cuadrada)
- **Formato**: JPG o PNG
- **Peso**: Máximo 200KB
- **Consejos**:
  - Fondo neutro o profesional
  - Buena iluminación
  - Vestimenta profesional
  - Mirada a la cámara
  - Sonrisa natural

### 2. Imágenes de Proyectos (project1.jpg - project6.jpg)
- **Tamaño**: 800x600px (4:3)
- **Formato**: JPG
- **Peso**: Máximo 300KB cada una
- **Tipos de capturas**:
  - Dashboards de monitoreo (Grafana, Prometheus)
  - Terminales con comandos
  - Arquitecturas de sistemas
  - Diagramas de red
  - Interfaces de administración
  - Capturas de código relevante

## 🖼️ Dónde Colocar las Imágenes

```
cv_online/
└── images/
    ├── profile.jpg      ← Tu foto de perfil
    ├── project1.jpg     ← Proyecto 1
    ├── project2.jpg     ← Proyecto 2
    ├── project3.jpg     ← Proyecto 3
    ├── project4.jpg     ← Proyecto 4
    ├── project5.jpg     ← Proyecto 5
    └── project6.jpg     ← Proyecto 6
```

## 🎨 Herramientas para Editar/Optimizar

### Online (Gratis)
- **Canva**: Para crear diseños profesionales
- **TinyPNG**: Para comprimir imágenes
- **Remove.bg**: Para eliminar fondos
- **Squoosh**: Para optimizar imágenes

### Software
- **GIMP**: Editor de imágenes gratuito
- **Paint.NET**: Simple y efectivo
- **Photoshop**: Si tienes acceso

## 📐 Plantillas de Proyectos

### Idea 1: Dashboard de Monitoreo
- Captura de Grafana/Prometheus
- Gráficos de rendimiento
- Métricas del sistema

### Idea 2: Terminal/Scripting
- Terminal con scripts de automatización
- Código de bash/PowerShell
- Logs de ejecución exitosa

### Idea 3: Arquitectura Cloud
- Diagrama de AWS/Azure
- Infraestructura as Code
- Topología de red

### Idea 4: Virtualización
- Panel de VMware/Proxmox
- Máquinas virtuales activas
- Recursos asignados

### Idea 5: Seguridad
- Firewall configurado
- Escaneos de seguridad
- Hardening aplicado

### Idea 6: Backup/DR
- Dashboard de backups
- Plan de disaster recovery
- Restore exitoso

## 🚨 Si No Tienes Imágenes Aún

El portafolio incluye **imágenes placeholder** (placeholders SVG) que se mostrarán automáticamente si no subes tus propias imágenes. Puedes:

1. **Dejarlo así temporalmente**: Los placeholders se ven profesionales
2. **Usar imágenes genéricas**: Busca en sitios de imágenes libres
3. **Crear mockups**: Usa herramientas online

## 🔗 Recursos de Imágenes Gratuitas

### Fotos Stock
- **Unsplash**: unsplash.com
- **Pexels**: pexels.com
- **Pixabay**: pixabay.com

### Iconos y Vectores
- **Flaticon**: flaticon.com
- **Icons8**: icons8.com
- **Undraw**: undraw.co (ilustraciones)

### Mockups Tecnológicos
- **Freepik**: freepik.com (con atribución)
- **Mockup World**: mockupworld.co

## ⚡ Optimización de Imágenes

### Antes de subir:
```bash
# Redimensionar (ejemplo con ImageMagick)
convert profile.jpg -resize 400x400^ -gravity center -extent 400x400 profile_optimized.jpg

# Comprimir
convert profile.jpg -quality 85 profile_compressed.jpg
```

### Herramientas Online:
1. Sube a TinyPNG.com
2. Descarga versión optimizada
3. Coloca en carpeta `images/`

## 📝 Checklist de Imágenes

- [ ] Foto de perfil profesional (400x400px)
- [ ] 6 imágenes de proyectos (800x600px)
- [ ] Todas las imágenes optimizadas (<300KB)
- [ ] Nombres correctos (profile.jpg, project1.jpg, etc.)
- [ ] Colocadas en carpeta `images/`
- [ ] Probadas en el navegador

## 💡 Tip Pro

Si trabajas con **datos sensibles**, asegúrate de:
- ✅ Ofuscar IPs y datos privados
- ✅ No mostrar información confidencial
- ✅ Usar ejemplos o entornos de prueba
- ✅ Pedir permiso si es proyecto de empresa

---

**Nota**: Si no tienes imágenes ahora, ¡no te preocupes! El portafolio funciona perfectamente con los placeholders incluidos. Puedes añadirlas más tarde.
