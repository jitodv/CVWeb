# GUÍA DE PERSONALIZACIÓN RÁPIDA

## 🎯 Pasos Esenciales (15 minutos)

### 1. INFORMACIÓN PERSONAL (index.html)

**Línea 61** - Tu nombre:
```html
<span class="gradient-text">Tu Nombre</span>
```

**Línea 75-79** - Enlaces sociales:
```html
<a href="https://www.linkedin.com/in/ruben-guerrero-l%C3%B3pez-638531240/">
<a href="https://github.com/jitodv">
<a href="mailto:rubenguerrero096@protonmail.com">

```

**Línea 106-111** - Descripción personal:
```html
<p>Soy un administrador de sistemas apasionado...</p>
```

**Línea 119-127** - Estadísticas (años, proyectos, certificaciones):
```html
<div class="stat-number">X+</div>
```

### 2. COLORES (styles.css)La 

**Líneas 5-8** - Cambiar colores principales:
```css
--primary-color: #667eea;      /* Azul/Púrpura */
--secondary-color: #764ba2;    /* Púrpura */
```

### 3. IMÁGENES

Coloca en la carpeta `images/`:
- `profile.jpg` - Tu foto (400x400px)
- `project1.jpg` hasta `project6.jpg` - Capturas de proyectos (800x600px)

### 4. CV PDF

Coloca tu CV como `cv.pdf` en la raíz del proyecto.

### 5. HABILIDADES (index.html)

**Líneas 145-280** - Ajusta porcentajes:
```html
<div class="skill-progress" data-progress="90"></div>
```

### 6. EXPERIENCIA (index.html)

**Líneas 290-360** - Actualiza trabajos, fechas y tecnologías.

### 7. PROYECTOS (index.html)

**Líneas 435-550** - Describe tus proyectos reales.

### 8. CONTACTO (index.html)

**Líneas 575-615** - Actualiza email, teléfono y ubicación.

## ⚡ Prueba Local

Abre `index.html` directamente en tu navegador o usa:

```bash
# Con Python 3
python -m http.server 8000

# Con Node.js
npx http-server

# Con PHP
php -S localhost:8000
```

Luego abre: `http://localhost:8000`

## 🚀 Despliegue Rápido

### GitHub Pages:
1. Sube a GitHub
2. Settings > Pages > Source: main branch
3. Listo en: `https://tu-usuario.github.io/repo`

### Netlify:
1. Arrastra carpeta a netlify.app/drop
2. Listo en segundos

## ✅ Checklist Mínimo

- [ ] Cambiar nombre
- [ ] Actualizar email y redes sociales
- [ ] Subir foto de perfil
- [ ] Modificar descripción personal
- [ ] Ajustar habilidades
- [ ] Añadir al menos 3 proyectos
- [ ] Probar en móvil
- [ ] Desplegar online

¡En 15 minutos tendrás tu portafolio listo! 🎉
